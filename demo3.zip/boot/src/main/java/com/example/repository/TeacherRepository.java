package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Admin;
import com.example.model.Teacher;

public interface TeacherRepository extends JpaRepository<Teacher,Long> {
	public Teacher findByUseridAndPassword(String userid,String password);

}
