package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Students;
import com.example.model.Teacher;

public interface StudentRepository extends JpaRepository<Students,Long> {
	public Students findByUseridAndPassword(String userid,String password);

}
